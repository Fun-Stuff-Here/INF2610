/*
 * Copyright (C) 2022, 1904635 Julie Labbe, 2083544 Nicolas Depelteau
 * Polytechnique Montréal
 */

#include "unistd.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <stdio.h>
#include <fcntl.h>

#define BUFFER_SIZE 1024
#define OUTPUT_FILE "Out.txt"
#define INPUT_FILE "In.txt"

int main() {

    int tube[2];
    if(pipe(tube) < 0)
    {
        perror("pipe");
        return 1;
    }

    if(!fork()) //P2
    {

        if(!fork()) //P1
        {
            dup2(tube[STDOUT_FILENO], STDOUT_FILENO);
            close(tube[STDIN_FILENO]);
            close(tube[STDOUT_FILENO]);

            execlp("rev", "rev", INPUT_FILE, NULL);

            _exit(0);
        }

        int outputFile = open(OUTPUT_FILE, O_WRONLY | O_CREAT | O_TRUNC, 0660);
        dup2(tube[STDIN_FILENO], STDIN_FILENO);
        dup2(outputFile, STDOUT_FILENO);

        close(tube[STDIN_FILENO]);
        close(tube[STDOUT_FILENO]);
        close(outputFile);

        execlp("rev", "rev", NULL);
        _exit(0);
    }

    close(tube[STDIN_FILENO]);
    close(tube[STDOUT_FILENO]);
    while(wait(NULL) > 0);

    if(!fork()) //P3
    {
        execlp("diff", "diff", INPUT_FILE, OUTPUT_FILE, NULL);
        _exit(0);
    }

    while(wait(NULL) > 0);
}
