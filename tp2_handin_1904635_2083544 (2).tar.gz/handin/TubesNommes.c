/*
 * Copyright (C) 2022, 1904635 Julie Labbe, 2083544 Nicolas Depelteau
 * Polytechnique Montréal
 */

#include "unistd.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <stdio.h>
#include <fcntl.h>

#define BUFFER_SIZE 1024
#define PIPE_NAME "pipe"
#define OUTPUT_FILE "Outn.txt"
#define INPUT_FILE "In.txt"

int main() {

    if(mkfifo(PIPE_NAME, 0660) < 0)
    {
        perror(PIPE_NAME);
        return 1;
    }

    if(!fork()) //P2
    {

        if(!fork()) //P1
        {
            int fileDescriptor = open(PIPE_NAME, O_WRONLY);
            dup2(fileDescriptor, STDOUT_FILENO);
            close(fileDescriptor);

            execlp("rev", "rev", INPUT_FILE, NULL);
            _exit(0);
        }

        int fileDescriptor = open(PIPE_NAME, O_RDONLY);
        dup2(fileDescriptor, STDIN_FILENO);
        close(fileDescriptor);

        int outputFile = open(OUTPUT_FILE, O_WRONLY | O_CREAT | O_TRUNC, 0660);
        dup2(outputFile, STDOUT_FILENO);
        close(outputFile);

        execlp("rev", "rev", NULL);

        _exit(0);
    }

    while(wait(NULL) > 0);
    unlink(PIPE_NAME);

    if(!fork()) //P3
    {
        execlp("diff", "diff", INPUT_FILE, OUTPUT_FILE, NULL);
        _exit(0);
    }

    while(wait(NULL) > 0);
}
