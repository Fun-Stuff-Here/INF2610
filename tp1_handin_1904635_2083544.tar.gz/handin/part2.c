/*
 * Ecole polytechnique de Montreal - GIGL
 * Automne  2022
 * Initlab - part2.c
 *
 * ajoutez vos noms, prénoms et matricules
 * Julie Labbe(1904635), Nicolas Depelteau(2083544), Section 01
*/
#include <stdio.h>
#include <stdlib.h>
// Si besoin, ajouter ici les directives d'inclusion et les déclarations globales
// -------------------------------------------------
// TODO
#include <unistd.h>
#include <string.h>

char* message1 = "77dbcb01f571f1c32e196c3a7d27f62e (printed using write)\n";
char* message2 = "77dbcb01f571f1c32e196c3a7d27f62e (printed using printf)";

// -------------------------------------------------
void part21 ()
{
 // TODO

 for (unsigned i = 0; i < strlen(message2); i++)
 {
    printf("%c", message2[i]);
 }

 write(1, message1, strlen(message1));
 
}

void part22 ()
{
 // TODO
 char buffer[1];
 setvbuf(stdout,buffer, _IONBF, 1);
 part21();
}



int main (int argc, char* argv[])
{
    
    if (argc!=2)
    {   printf("Le programme a un seul paramètre : 1 ou 2\n");
        return 1;
    }
    switch (atoi(argv[1])) {
         case 1:        part21();
                        break;
         case 2:        part22();
                        break;
        default:        printf(" Le paramètre du programme est invalide\n");
                        return 1;
    }
    return 0;
}

