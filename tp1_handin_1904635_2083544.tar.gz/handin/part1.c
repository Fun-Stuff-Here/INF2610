/*
 * Ecole polytechnique de Montreal - GIGL
 * Automne  2022
 * Initlab - part1.c
 * 
 * ajoutez vos noms, prénoms, matricules et votre section de laboratoire
 * Julie Labbe(1904635), Nicolas Depelteau(2083544), Section 01
 */

// TODO
// Si besoin, ajouter ici les directives d'inclusion et les déclarations globales
// -------------------------------------------------
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>

#define BUFFER_SIZE 1024
#define CHECK_ERROR(x) do {if(x<0) {perror("Appel systeme Open a echoue\n"); return(1);}} while(0);
// -------------------------------------------------

int main (int argc, char** argv) 
{
    int fileDescriptor = open("output2.txt", O_WRONLY|O_APPEND|O_TRUNC);
    CHECK_ERROR(fileDescriptor);

    char* outString = "Saisissez votre texte suivi de CTRL-D: \n";
    CHECK_ERROR(write(1, outString, strlen(outString)));

    char buffer[BUFFER_SIZE];
    int nb = 0;
    do
    {
        nb = read(0, buffer, BUFFER_SIZE);
        CHECK_ERROR(nb);
        if(nb>0)
        {
            CHECK_ERROR(write(fileDescriptor, buffer, nb));
        }
    } while (nb >= BUFFER_SIZE);

    close(fileDescriptor);

    return(0);
}
