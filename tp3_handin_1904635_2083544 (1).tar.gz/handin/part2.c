/*
 * processlab - part2.c
 *
 * Ecole polytechnique de Montreal, GIGL, Automne  2022
 * Julie Labbe 1904635, Nicolas Depelteau 2083544
*/

// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------
#include "pthread.h"
// -------------------------------------------------

#include "./libprocesslab/libprocesslab.h"

#define m 1000000l
// question2 calcule la somme des m premiers nombres naturels 1+2+...+m

// nb est le nombre de threads qui vont contribuer au calcul
#define nb 4l

//tableau somme est utilisé pour le calcul des sommes patielles par les threads
long somme[nb];

// fonction exécutée par chaque thread créé
void* contribution(void*p)
{
  // TODO
  long no = (long) p;

  somme[no] = 0;
  for (long i = (no*m)/nb + 1; i <= (no+1l)*m/nb; ++i)
  {
    somme[no] += i;
  }

  pthread_exit(NULL);
}


void question2( )
{
  // TODO
  pthread_t tids[nb];
  for(long i = 0; i<nb; ++i)
  {
    pthread_create(&tids[i], NULL, contribution, (long*)i);
  }

  long total = 0;
  for(unsigned i = 0; i<nb; ++i)
    pthread_join(tids[i], NULL);

  for(unsigned i = 0; i<nb; ++i)
    total += somme[i];

  printf("Somme des threads = %ld, m*(m+1)/2 = %ld\n", total, (m*(m+1))/2l);
}
