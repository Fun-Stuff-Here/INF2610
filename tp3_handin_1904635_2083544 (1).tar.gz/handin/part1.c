/*
 * processlab - part1.c
 * 
 * Ecole polytechnique de Montreal, GIGL, Automne  2022
 * Julie Labbe 1904635, Nicolas Depelteau 2083544
*/

#include "libprocesslab/libprocesslab.h"

// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------
#include "unistd.h"
#include "sys/wait.h"
// -------------------------------------------------

void question1()
{
    registerProc(getpid(), getppid(), 0, 0);
    
    if(!fork()) // fils 1.1
    {
        registerProc(getpid(), getppid(), 1, 1);

        if(!fork()) // fils 2.1
        {
            registerProc(getpid(), getppid(), 2, 1);
            _exit(1);
        }
        if(!fork()) // fils 2.2
        {
            registerProc(getpid(), getppid(), 2, 2);
            _exit(1);
        }
        int status;
        int nbFils = 1; // on compte lui-meme comme etant enfant de son parent
        while((wait(&status))>0){
            nbFils += WEXITSTATUS(status);
        }
        _exit(nbFils);
    }

    if(!fork())// fils 1.2
    {
        registerProc(getpid(), getppid(), 1, 2);

        if(!fork()) // fils 2.3
        {
            registerProc(getpid(), getppid(), 2, 3);
            _exit(1);
        }
        int status;
        int nbFils = 1; // on compte lui-meme comme etant enfant de son parent
        while((wait(&status))>0){
            nbFils += WEXITSTATUS(status);
        }
        _exit(nbFils);
    }

    if(!fork())// fils 1.3
    {
        registerProc(getpid(), getppid(), 1, 3);
        if(!fork()) // fils 2.4
        {
            registerProc(getpid(), getppid(), 2, 4);
            _exit(1);
        }
        if(!fork()) // fils 2.5
        {
            registerProc(getpid(), getppid(), 2, 5);
            _exit(1);
        }
        if(!fork()) // fils 2.6
        {
            registerProc(getpid(), getppid(), 2, 6);
            _exit(1);
        }
        int status;
        int nbFils = 1; // on compte lui-meme comme etant enfant de son parent
        while((wait(&status))>0){
            nbFils += WEXITSTATUS(status);
        }
        _exit(nbFils);
    }

    int status;
    int nbFils = 0;
    while((wait(&status))>0){
        nbFils += WEXITSTATUS(status);
    }
    printf("Nombre d'enfants directs et indirects au niveau 0: %i\n", nbFils);
    printProcRegistrations();
    execlp("ls", "ls", "-l", NULL);
}
